import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
   return MaterialApp(
   title: 'Aplikasi O-kos',
   theme: ThemeData(
      primarySwatch: Colors.green,
   ),
   home: Scaffold(
        appBar: AppBar(
          title: Text('O kos APP'),
        ),
        body: Center(
          child: Text('welcome to O-kos'),
        ),
      ),
);
  }

}